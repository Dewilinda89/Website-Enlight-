<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class PageController extends Controller
{
    public function category(){
      return view('tampilan/category');
    }
    public function index(){
      return view('home');
    }
    public function home(){
      return view('home');
    }
    public function shop(){
      return view('shop');
    }
    public function animal(){
      return view('animal');
    }
    public function buah(){
      return view('buah');
    }
    public function kuis(){
      return view('kuis');
    }

}
