<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <title>Elsa Theme - Multipurpose Template from Andreas Lautenschlager</title>

    <!-- normalize core CSS -->
    <link href="css/normalize.css" rel="stylesheet">

    <!-- Bootstrap core CSS -->
    <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="bootstrap/css/carousel.css" rel="stylesheet">
    <link href="bootstrap/fonts/glyphicons-halflings-regular.eot" rel="stylesheet">

    <!-- Load jQuery -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>


    <!-- Google Fonts - Change if needed -->
    <link href='https://fonts.googleapis.com/css?family=Source+Sans+Pro:400italic,400,700,300,600' rel='stylesheet' type='text/css'>
    <link href='https://fonts.googleapis.com/css?family=Oxygen:400,700,300' rel='stylesheet' type='text/css'>

    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">

    <!-- Menu shrinking -->
    <script type="text/javascript" src="js/menu.js"></script>

    <!-- Main styles of this template -->
    <link href="css/style.css" rel="stylesheet">

    <!-- Custom CSS. Input here your changes -->
    <link href="custom.css" rel="stylesheet">

</head>

<body>


    <!-- Navigation -->
    <div class="navbar navbar-default navbar-fixed-top" role="navigation">
        <div class="container">
            <div class="navbar-header page-scroll">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a href="index.html"><img class="logo" src="img/logo.png" alt="Logo"></a>
            </div>
            <nav class="collapse navbar-collapse navbar-ex1-collapse">
                <ul class="nav navbar-nav navbar-right">
                    <li><a href="category.html">Category</a></li>
                    <li><a href="contact.html">Exercise</a></li>
                    <li><a href="contact.html">Shop</a></li>
                    <li><a href="components.html">Components</a></li>

                </ul>

            </nav>
            <!-- /.navbar-collapse -->
        </div>
        <div class="logout">

        </div>
        <!-- /.container -->
    </div>




    <!-- Carousel Header -->
    <header>
        <div id="carousel-header" class="carousel slide">
            <!-- Indicators -->
            <ol class="carousel-indicators hidden-xs">
                <li data-target="#carousel-header" data-slide-to="0" class="active"></li>
                <li data-target="#carousel-header" data-slide-to="1"></li>
                <li data-target="#carousel-header" data-slide-to="2"></li>
            </ol>
            <!-- Wrapper for slides -->
            <div class="carousel-inner">
                <div class="item active">
                    <img class="img-responsive img-full" src="http://merrygolearn.com/mglv4Rise/wp-content/uploads/2017/05/main-qimg-a064ac4892fbd83201f3f7b7be334164-c.jpg" alt="">
                    <div class="carousel-caption">
                        <h3>Animal</h3>
                        <p>Learn english</p>
                    </div>
                </div>
                <div class="item">
                    <a href="category.html"><img class="img-responsive img-full"  src="img/vehicle.jpg" alt=""></a>
                    <div class="carousel-caption">
                        <h3>Slide 2</h3>
                        <p>Description for Slide 2</p>
                    </div>
                </div>
                <div class="item">
                    <img class="img-responsive img-full" src="img/latihan.jpg" alt="">
                    <div class="carousel-caption">
                        <h3>Slide 3</h3>
                        <p>Description for Slide 3</p>
                    </div>
                </div>
            </div>
            <!-- Controls -->
            <a class="left carousel-control" href="#carousel-header" data-slide="prev">
                <span class="icon-prev"></span>
            </a>
            <a class="right carousel-control" href="#carousel-header" data-slide="next">
                <span class="icon-next"></span>
            </a>
        </div>

        <!-- best selling -->
        <section class="page-section">
            <div class="container ">
                <div class="row">
                    <div class="col-md-8 col-md-push-4">
                        <div class="col-md-12">
                            <h2 class="title-section"><span >BEST SELLING</span><br/><span class="title-regular">ENGLISH FOR EVERYONE</span></h2>
                            <hr class="title-underline" />
                        </div>
                        <div class="row">
                            <div class="col-md-6 ">
                                <div class="col-xs-2 box-icon">
                                    <div class="fa fa-pencil "></div>
                                </div>
                                <div class="col-xs-10">
                                    <h3>Easy to Learn</h3>
                                </div>
                                <div class="col-md-10 col-xs-offset-2">
                                    <p>
                                        Buku ini sangat mudah untuk dipelajari anak anak dan juga memiliki konten yang lumayan banyak,
                                    </p>
                                </div>
                            </div>
                            <div class="col-md-6 ">

                                <div class="col-xs-2 box-icon">
                                    <div class="fa fa-wordpress "></div>
                                </div>
                                <div class="col-xs-10">
                                    <h3>Tons of Vocabulary</h3>
                                </div>
                                <div class="col-md-10 col-xs-offset-2">
                                    <p>
                                        Memiliki berbagai vocabulary dari bermacam macam kategori benda di lingkungan sekitar
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6 ">

                                <div class="col-xs-2 box-icon">
                                    <div class="fa fa-eye "></div>
                                </div>
                                <div class="col-xs-10">
                                    <h3>Colorful Display</h3>
                                </div>
                                <div class="col-md-10 col-xs-offset-2">
                                    <p>
                                        Buku ini memiliki tampilan yang berwarna warni sehingga sangat menarik bagi anak anak
                                    </p>
                                </div>
                            </div>
                            <div class="col-md-6 ">

                                <div class="col-xs-2 box-icon">
                                    <div class="fa fa-bullseye "></div>
                                </div>
                                <div class="col-xs-10">
                                    <h3>Free Online Audio</h3>
                                </div>
                                <div class="col-md-10 col-xs-offset-2">
                                    <p>
                                        Buku ini menyediakan course menggunakan audio gratis secara online
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4 col-md-pull-8 ">
                        <img class="img-responsive" src="img/eng.jpg" alt="" />
                    </div>
                </div>
            </div>
        </section>
        <script src="bootstrap/js/bootstrap.min.js"></script>


    </header>
<?php /**PATH C:\xampp\htdocs\blog\resources\views/index.blade.php ENDPATH**/ ?>