<!DOCTYPE html>
<html lang="zxx">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Elsa, a multipurpose Template from Andreas Lautenschlager">
    <meta name="author" content="Andreas Lautenschlager - www.lautenschlager.de">

    <title>Elsa Theme - Multipurpose Template from Andreas Lautenschlager</title>

    <!-- normalize core CSS -->
    <link href="css/normalize.css" rel="stylesheet">

    <!-- Bootstrap core CSS -->
    <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="bootstrap/css/carousel.css" rel="stylesheet">
    <link href="bootstrap/fonts/glyphicons-halflings-regular.eot" rel="stylesheet">

    <!-- Load jQuery -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>

    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <link href="bootstrap/css/ie10-viewport-bug-workaround.css" rel="stylesheet">

    <script src="bootstrap/js/ie-emulation-modes-warning.js"></script>

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->

    <!-- Google Fonts - Change if needed -->
    <link href='https://fonts.googleapis.com/css?family=Source+Sans+Pro:400italic,400,700,300,600' rel='stylesheet' type='text/css'>
    <link href='https://fonts.googleapis.com/css?family=Oxygen:400,700,300' rel='stylesheet' type='text/css'>

    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">

    <!-- Menu shrinking -->
    <script type="text/javascript" src="js/menu.js"></script>

    <!-- Main styles of this template -->
    <link href="css/style.min.css?v=1.0.0" rel="stylesheet">

    <!-- Custom CSS. Input here your changes -->
    <link href="css/custom.css" rel="stylesheet">

</head>

<body>
  <header>
    <div class="navbar navbar-default navbar-fixed-top" role="navigation">
        <div class="container">
            <div class="navbar-header page-scroll">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>

                </button>
                <a href="/index"><img class="logo" src="img/light.png" alt="Logo"></a>
            </div>
            <nav class="collapse navbar-collapse navbar-ex1-collapse">
                <ul class="nav navbar-nav navbar-right">
                    <li><a href="home">Home</a></li>
                    <li><a href="category">Category</a></li>
                    <li><a href="contact.html">Exercise</a></li>
                    <li><a href="shop">Shop</a></li>
                    <li><a href="animal">About Us</a></li>
                    <li><a href="components.html">Log Out</a></li>
                </ul>

            </nav>

            <!-- /.navbar-collapse -->
          </div>
          <!-- /.container -->
      </div>
      <script src="bootstrap/js/bootstrap.min.js"></script>

    </header>

<section class="filter-section">
        <div class="container">
            <div class="row">
                <div class="col-sm-12 col-xs-12">

                    <h1>All Kind of Animals</h1>

                    <div class="filter-container isotopeFilters">
                        <ul class="list-inline filter">
                            <li class="active"><a href="#" data-filter="*">All </a><span>/</span></li>
                            <li><a href="#" data-filter=".illustrations">Birds</a><span>/</span></li>
                            <li><a href="#" data-filter=".photography">Fish</a><span>/</span></li>
                            <li><a href="#" data-filter=".websites">Mammals</a><span>/</span></li>
                            <li><a href="#" data-filter=".art">Reptile</a></li>
                        </ul>
                    </div>

                </div>
            </div>
        </div>
<section class="portfolio-section port-col">
      <div class="container">
          <div class="row">
              <div class="isotopeContainer">
                  <div class="col-md-3 isotopeSelector art">
                      <article class="">
                          <figure>
                              <img src="https://asset.kompas.com/crop/0x0:1000x667/750x500/data/photo/2018/08/31/185781167.jpg" alt="">
                              <div class="overlay-background">
                                  <div class="inner"></div>
                                  <h3>Snake</h3>
                                  <h4>Ular</h4>
                              </div>
                              <div class="overlay">
                                  <div class="inner-overlay">
                                      <div class="row margin-0 project-content">
                                          <div class="col-md-12 info-head">
                                              <h3>Hiu</h3>
                                              <h4>Shark</h4>
                                          </div>
                                          <div class="col-md-12 info">
                                              <p>Lorem ipsum dolor...</p>
                                              <p><a title="Project Image" class="fancybox-pop fancybox.image" href="https://asset.kompas.com/crop/0x0:1000x667/750x500/data/photo/2018/08/31/185781167.jpg"><i class="fa fa-search fa-border fa-2x"></i></a>
                                                  <a title="Project Link" href="portfolio-item.html"><i class="fa fa-link fa-border fa-2x"></i></a></p>
                                          </div>
                                      </div>
                                  </div>
                              </div>
                          </figure>
                      </article>
                  </div>
                  <div class="col-md-3 isotopeSelector illustrations">
                      <article class="">
                          <figure>
                              <img src="img/eagle.jpg" alt="">
                              <div class="overlay-background">
                                  <div class="inner"></div>
                              </div>
                              <div class="overlay">
                                  <div class="inner-overlay">
                                      <div class="row margin-0 project-content">
                                          <div class="col-md-12 info-head">
                                              <h3>Eagle</h3>
                                              <h4>Elang</h4>
                                          </div>
                                          <div class="col-md-12 info">
                                              <p><a title="Project Image" class="fancybox-pop fancybox.image" href="img/eagle.jpg"><i class="fa fa-search fa-border fa-2x"></i></a>
                                                  <a title="Project Link" href="https://en.wikipedia.org/wiki/Eagle"><i class="fa fa-link fa-border fa-2x"></i></a></p>
                                          </div>
                                      </div>
                                  </div>
                              </div>
                          </figure>
                      </article>
                  </div>
                  <div class="col-md-3 isotopeSelector websites">
                      <article class="">
                          <figure>
                              <img src="img/lion.jpg" alt="">
                              <div class="overlay-background">
                                  <div class="inner"></div>
                              </div>
                              <div class="overlay">
                                  <div class="inner-overlay">
                                      <div class="row margin-0 project-content">
                                          <div class="col-md-12 info-head">
                                              <h3>Lion</h3>
                                              <h4>Singa</h4>
                                          </div>
                                          <div class="col-md-12 info">
                                              <p><a title="Project Image" class="fancybox-pop fancybox.image" href="img/lion.jpg"><i class="fa fa-search fa-border fa-2x"></i></a>
                                                  <a title="Project Link" href="portfolio-item.html"><i class="fa fa-link fa-border fa-2x"></i></a></p>
                                          </div>
                                      </div>
                                  </div>
                              </div>
                          </figure>
                      </article>
                  </div>
                  <div class="col-md-3 isotopeSelector photography">
                      <article class="">
                          <figure>
                              <img src="https://asset-a.grid.id/crop/0x0:0x0/700x465/photo/2018/08/15/3672539939.jpg" alt="">
                              <div class="overlay-background">
                                  <div class="inner"></div>
                              </div>
                              <div class="overlay">
                                  <div class="inner-overlay">
                                      <div class="row margin-0 project-content">
                                          <div class="col-md-12 info-head">
                                              <h3>Project Title</h3>
                                              <h4>Category</h4>
                                          </div>
                                          <div class="col-md-12 info">
                                              <p>Lorem ipsum dolor...</p>
                                              <p><a title="Project Image" class="fancybox-pop fancybox.image" href="https://asset-a.grid.id/crop/0x0:0x0/700x465/photo/2018/08/15/3672539939.jpg"><i class="fa fa-search fa-border fa-2x"></i></a>
                                                  <a title="Project Link" href="portfolio-item.html"><i class="fa fa-link fa-border fa-2x"></i></a></p>
                                          </div>
                                      </div>
                                  </div>
                              </div>
                          </figure>
                      </article>
                  </div>
                  <div class="col-md-3 isotopeSelector photography">
                      <article class="">
                          <figure>
                              <img src="http://placehold.it/625x450" alt="">
                              <div class="overlay-background">
                                  <div class="inner"></div>
                              </div>
                              <div class="overlay">
                                  <div class="inner-overlay">
                                      <div class="row margin-0 project-content">
                                          <div class="col-md-12 info-head">
                                              <h3>Project Title</h3>
                                              <h4>Category</h4>
                                          </div>
                                          <div class="col-md-12 info">
                                              <p>Lorem ipsum dolor...</p>
                                              <p><a title="Project Image" class="fancybox-pop fancybox.image" href="http://placehold.it/625x450"><i class="fa fa-search fa-border fa-2x"></i></a>
                                                  <a title="Project Link" href="portfolio-item.html"><i class="fa fa-link fa-border fa-2x"></i></a></p>
                                          </div>
                                      </div>
                                  </div>
                              </div>
                          </figure>
                      </article>
                  </div>
                  <div class="col-md-3 isotopeSelector art">
                      <article class="">
                          <figure>
                              <img src="http://placehold.it/625x450" alt="">
                              <div class="overlay-background">
                                  <div class="inner"></div>
                              </div>
                              <div class="overlay">
                                  <div class="inner-overlay">
                                      <div class="row margin-0 project-content">
                                          <div class="col-md-12 info-head">
                                              <h3>Project Title</h3>
                                              <h4>Category</h4>
                                          </div>
                                          <div class="col-md-12 info">
                                              <p>Lorem ipsum dolor...</p>
                                              <p><a title="Project Image" class="fancybox-pop fancybox.image" href="http://placehold.it/625x450"><i class="fa fa-search fa-border fa-2x"></i></a>
                                                  <a title="Project Link" href="portfolio-item.html"><i class="fa fa-link fa-border fa-2x"></i></a></p>
                                          </div>
                                      </div>
                                  </div>
                              </div>
                          </figure>
                      </article>
                  </div>
                  <div class="col-md-3 isotopeSelector photography">
                      <article class="">
                          <figure>
                              <img src="http://placehold.it/625x450" alt="">
                              <div class="overlay-background">
                                  <div class="inner"></div>
                              </div>
                              <div class="overlay">
                                  <div class="inner-overlay">
                                      <div class="row margin-0 project-content">
                                          <div class="col-md-12 info-head">
                                              <h3>Project Title</h3>
                                              <h4>Category</h4>
                                          </div>
                                          <div class="col-md-12 info">
                                              <p>Lorem ipsum dolor...</p>
                                              <p><a title="Project Image" class="fancybox-pop fancybox.image" href="http://placehold.it/625x450"><i class="fa fa-search fa-border fa-2x"></i></a>
                                                  <a title="Project Link" href="portfolio-item.html"><i class="fa fa-link fa-border fa-2x"></i></a></p>
                                          </div>
                                      </div>
                                  </div>
                              </div>
                          </figure>
                      </article>
                  </div>
                  <div class="col-md-3 isotopeSelector photography websites">
                      <article class="">
                          <figure>
                              <img src="http://placehold.it/625x450" alt="">
                              <div class="overlay-background">
                                  <div class="inner"></div>
                              </div>
                              <div class="overlay">
                                  <div class="inner-overlay">
                                      <div class="row margin-0 project-content">
                                          <div class="col-md-12 info-head">
                                              <h3>Project Title</h3>
                                              <h4>Category</h4>
                                          </div>
                                          <div class="col-md-12 info">
                                              <p>Lorem ipsum dolor...</p>
                                              <p><a title="Project Image" class="fancybox-pop fancybox.image" href="http://placehold.it/625x450"><i class="fa fa-search fa-border fa-2x"></i></a>
                                                  <a title="Project Link" href="portfolio-item.html"><i class="fa fa-link fa-border fa-2x"></i></a></p>
                                          </div>
                                      </div>
                                  </div>
                              </div>
                          </figure>
                      </article>
                  </div>
                  <div class="col-md-3 isotopeSelector photography art">
                      <article class="">
                          <figure>
                              <img src="http://placehold.it/625x450" alt="">
                              <div class="overlay-background">
                                  <div class="inner"></div>
                              </div>
                              <div class="overlay">
                                  <div class="inner-overlay">
                                      <div class="row margin-0 project-content">
                                          <div class="col-md-12 info-head">
                                              <h3>Project Title</h3>
                                              <h4>Category</h4>
                                          </div>
                                          <div class="col-md-12 info">
                                              <p>Lorem ipsum dolor...</p>
                                              <p><a title="Project Image" class="fancybox-pop fancybox.image" href="http://placehold.it/625x450"><i class="fa fa-search fa-border fa-2x"></i></a>
                                                  <a title="Project Link" href="portfolio-item.html"><i class="fa fa-link fa-border fa-2x"></i></a></p>
                                          </div>
                                      </div>
                                  </div>
                              </div>
                          </figure>
                      </article>
                  </div>
                  <div class="col-md-3 isotopeSelector illustrations">
                      <article class="">
                          <figure>
                              <img src="http://placehold.it/625x450" alt="">
                              <div class="overlay-background">
                                  <div class="inner"></div>
                              </div>
                              <div class="overlay">
                                  <div class="inner-overlay">
                                      <div class="row margin-0 project-content">
                                          <div class="col-md-12 info-head">
                                              <h3>Project Title</h3>
                                              <h4>Category</h4>
                                          </div>
                                          <div class="col-md-12 info">
                                              <p>Lorem ipsum dolor...</p>
                                              <p><a title="Project Image" class="fancybox-pop fancybox.image" href="http://placehold.it/625x450"><i class="fa fa-search fa-border fa-2x"></i></a>
                                                  <a title="Project Link" href="portfolio-item.html"><i class="fa fa-link fa-border fa-2x"></i></a></p>
                                          </div>
                                      </div>
                                  </div>
                              </div>
                          </figure>
                      </article>
                  </div>
                  <div class="col-md-3 isotopeSelector art websites">
                      <article class="">
                          <figure>
                              <img src="http://placehold.it/625x450" alt="">
                              <div class="overlay-background">
                                  <div class="inner"></div>
                              </div>
                              <div class="overlay">
                                  <div class="inner-overlay">
                                      <div class="row margin-0 project-content">
                                          <div class="col-md-12 info-head">
                                              <h3>Project Title</h3>
                                              <h4>Category</h4>
                                          </div>
                                          <div class="col-md-12 info">
                                              <p>Lorem ipsum dolor...</p>
                                              <p><a title="Project Image" class="fancybox-pop fancybox.image" href="http://placehold.it/625x450"><i class="fa fa-search fa-border fa-2x"></i></a>
                                                  <a title="Project Link" href="portfolio-item.html"><i class="fa fa-link fa-border fa-2x"></i></a></p>
                                          </div>
                                      </div>
                                  </div>
                              </div>
                          </figure>
                      </article>
                  </div>
                  <div class="col-md-3 isotopeSelector websites">
                      <article class="">
                          <figure>
                              <img src="http://placehold.it/625x450" alt="">
                              <div class="overlay-background">
                                  <div class="inner"></div>
                              </div>
                              <div class="overlay">
                                  <div class="inner-overlay">
                                      <div class="row margin-0 project-content">
                                          <div class="col-md-12 info-head">
                                              <h3>Project Title</h3>
                                              <h4>Category</h4>
                                          </div>
                                          <div class="col-md-12 info">
                                              <p>Lorem ipsum dolor...</p>
                                              <p><a title="Project Image" class="fancybox-pop fancybox.image" href="http://placehold.it/625x450"><i class="fa fa-search fa-border fa-2x"></i></a>
                                                  <a title="Project Link" href="portfolio-item.html"><i class="fa fa-link fa-border fa-2x"></i></a></p>
                                          </div>
                                      </div>
                                  </div>
                              </div>
                          </figure>
                      </article>
                  </div>
              </div>
          </div>
          <h1><a href="laravel-crud-image-gallery" class="btn btn-md btn-primary ">Recommend</a></h1>
      </div>
  </section>



  <footer>
    <div class="container">
        <div class="row">
            <div class="col-md-3 ">
                <div>
                    <a href="index.html">
                        <img class="footer-logo" src="img/light.png" alt="logo">
                    </a>
                </div>
                <div>
                    <address class="margin-bottom-30">
                        <p>Perumahan Wika<br/>
                        Blok C1/3<br/>
                        Balikpapan</p>
                    </address>
                </div>
                <div class="margin-bottom-30">
                    <p><i class="fa fa-phone"></i> +49 561 00 00 00 00
                        <br/>
                        <i class="fa fa-fax"></i> +49 561 00 00 00 00</p>
                </div>
                <div>
                    <a>More Info</a>
                    <br/>
                    <a href="https://youtu.be/oBHbnxi-XVk">fahrizzait@gmail.com</a>
                </div>
            </div>
            <div class="col-md-3 footer-menu">
                <h4>About Us</h4>
                <p>Nam liber tempor cum soluta nobis eleifend option congue nihil imperdiet doming id quod mazim placerat facer possim assum.</p>
                <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. </p>
                <a href="about-us.html">
                    <button class="btn btn-primary">Read More</button>
                </a>
            </div>
            <div class="col-md-3 footer-blog">
                <h4>Our Team</h4>
                <ul>
                    <li><a href="#">Fahrizza<br/></a> <a href="#">CEO </a></li>
                    <li><a href="#">Sarah<br/></a> <a href="#">Branch Manager</a></li>
                    <li><a href="#">Wulan<br/></a> <a href="#">Branch Service Manager </a></li>
                </ul>
            </div>
            <div class="col-md-3  footer-menu">
                <h4>NAVIGATE</h4>
                <ul>
                    <a href="home">
                        <li>Home</li>
                    </a>
                    <a href="category">
                        <li>Category</li>
                    </a>
                    <a href="exercise">
                        <li>Exercise</li>
                    </a>
                    <a href="shop">
                        <li>Shop</li>
                    </a>
                    <a href="blog-right-sidebar.html">
                        <li>Blog</li>
                    </a>
                    <a href="contact.html">
                        <li>Contact</li>
                    </a>
                </ul>
            </div>

        </div>
    </div>

</footer>
    <!-- Scripts -->

        <!-- Loads Bootstrap Main JS -->
        <script src="bootstrap/js/bootstrap.min.js"></script>

        <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
        <script src="bootstrap/js/ie10-viewport-bug-workaround.js"></script>

        <!-- Initiate Portoflio Script -->
        <script src="extensions/portfolio/isotope.min.js"></script>
        <script src="extensions/portfolio/portfolio.js"></script>

        <!-- Initiate Fancybox/Lightbox Script -->
        <script type="text/javascript" src="extensions/fancybox/jquery.fancybox.js"></script>
        <script type="text/javascript" src="extensions/fancybox/jquery.fancybox.pack.js"></script>
        <link rel="stylesheet" type="text/css" href="extensions/fancybox/jquery.fancybox.css" media="screen" />
        <script type="text/javascript" src="extensions/fancybox/jquery.fancybox-media.js"></script>

      </body>
<?php /**PATH C:\xampp\htdocs\blog\resources\views/animal.blade.php ENDPATH**/ ?>