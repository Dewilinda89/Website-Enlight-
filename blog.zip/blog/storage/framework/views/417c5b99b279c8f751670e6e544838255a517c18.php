<div class="page-header">
      <div class="container">
          <div class="row">
              <div class="col-md-12">
                  <ul class="breadcrumb">
                      <li><a href="index.html">Home</a></li>
                      <li><a href="#">Shop</a></li>
                      <li>English for Everyone</li>
                  </ul>
              </div>
          </div>
          <div class="row">
              <div class="col-md-12">
                  <h1>English for Everyone</h1>
              </div>
          </div>
      </div>
  </div>





  <!-- Container  -->
  <section class="page-section padding-30">
      <div class="container">
          <div class="row">
              <!-- Content -->
              <div class="col-md-8 col-md-push-4 margin-bottom-15">
                  <a title="Main Image" class="fancybox-pop fancybox.image" href="http://placehold.it/1140x642" rel="portfolio-main">
                      <img src="img/eng.jpg" alt="portfolio" class="img-responsive">
                  </a>
              </div>


              <!-- Sidebar -->


              <div class="col-md-4 col-md-pull-8">

                  <h1>English for Everyone</h1>
                  <div class="portfolio-details">
                      <h3>
                          <strong>Price:</strong> Rp.20.000
                          <br/>
                          <strong>Seller:</strong> Ibnu
                          <br/>
                          <strong>Stock:</strong> Available
                          <br/>
                          <strong>Contact Person:</strong> @nikitasarah
                      </h3>
                        <strong><h1>Detail:</h1></strong>
                      <p>Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet.</p>
                  </div>

              </div>

          </div>

      </div>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\blog\resources\views/shop.blade.php ENDPATH**/ ?>