<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <title>Enlight</title>

    <!-- normalize core CSS -->
    <link href="css/normalize.css" rel="stylesheet">

    <!-- Bootstrap core CSS -->
    <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="bootstrap/css/carousel.css" rel="stylesheet">
    <link href="bootstrap/fonts/glyphicons-halflings-regular.eot" rel="stylesheet">
    <link rel="stylesheet" href="quiz/style.css">

    <!-- Load jQuery -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>


    <!-- Google Fonts - Change if needed -->
    <link href='https://fonts.googleapis.com/css?family=Source+Sans+Pro:400italic,400,700,300,600' rel='stylesheet' type='text/css'>
    <link href='https://fonts.googleapis.com/css?family=Oxygen:400,700,300' rel='stylesheet' type='text/css'>

    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">

    <!-- Menu shrinking -->
    <script type="text/javascript" src="js/menu.js"></script>

    <link href="bootstrap/css/carousel.css" rel="stylesheet">

    <!-- Main styles of this template -->
    <link href="css/style.css" rel="stylesheet">

    <!-- Custom CSS. Input here your changes -->
    <link href="css/custom.css" rel="stylesheet">

</head>

<body>

  <header>
    <div class="navbar navbar-default navbar-fixed-top" role="navigation">
        <div class="container">
            <div class="navbar-header page-scroll">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>

                </button>
                <a href="home"><img class="logo" src="img/light.png" alt="Logo"></a>
            </div>
            <nav class="collapse navbar-collapse navbar-ex1-collapse">
                <ul class="nav navbar-nav navbar-right">
                    <li><a href="home">Home</a></li>
                    <li><a href="category">Category</a></li>
                    <li><a href="kuis">Exercise</a></li>
                    <li><a href="shop">Shop</a></li>
                    <li><a href="/">Log Out</a></li>
                </ul>

            </nav>

            <!-- /.navbar-collapse -->
          </div>
          <!-- /.container -->
      </div>
      <script src="bootstrap/js/bootstrap.min.js"></script>

    </header>
    <?php echo $__env->yieldContent('content'); ?>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.3/umd/popper.min.js" integrity="sha384-vFJXuSJphROIrBnz7yo7oB41mKfc8JzQZiCq4NCceLEaO4IHwicKwpJf9c9IpFgh" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.2/js/bootstrap.min.js" integrity="sha384-alpBpkh1PFOepccYVYDB4do5UnbKysX5WZXm3XxPqe5iKTfUKjNkCk9SaVuEZflJ" crossorigin="anonymous"></script>
    <?php echo $__env->yieldContent('js'); ?>
    <footer>
      <div class="container">
          <div class="row">
              <div class="col-md-3 ">
                  <div>
                      <a href="index.html">
                          <img class="footer-logo" src="img/light.png" alt="logo">
                      </a>
                  </div>
                  <div>
                      <address class="margin-bottom-30">
                          <p>Perumahan Wika<br/>
                          Blok C1/3<br/>
                          Balikpapan</p>
                      </address>
                  </div>
                  <div class="margin-bottom-30">
                      <p><i class="fa fa-phone"></i> +49 561 00 00 00 00
                          <br/>
                          <i class="fa fa-fax"></i> +49 561 00 00 00 00</p>
                  </div>
                  <div>
                      <a>More Info</a>
                      <br/>
                      <a href="https://youtu.be/oBHbnxi-XVk">fahrizzait@gmail.com</a>
                  </div>
              </div>
              <div class="col-md-3 footer-menu">
                  <h4>About Us</h4>
                  <p>Nam liber tempor cum soluta nobis eleifend option congue nihil imperdiet doming id quod mazim placerat facer possim assum.</p>
                  <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. </p>
                  <a href="about-us.html">
                      <button class="btn btn-primary">Read More</button>
                  </a>
              </div>
              <div class="col-md-3 footer-blog">
                  <h4>Our Team</h4>
                  <ul>
                      <li><a href="#">Fahrizza<br/></a> <a href="#">CEO </a></li>
                      <li><a href="#">Sarah<br/></a> <a href="#">Branch Manager</a></li>
                      <li><a href="#">Wulan<br/></a> <a href="#">Branch Service Manager </a></li>
                  </ul>
              </div>
              <div class="col-md-3  footer-menu">
                  <h4>NAVIGATE</h4>
                  <ul>
                      <a href="home">
                          <li>Home</li>
                      </a>
                      <a href="category">
                          <li>Category</li>
                      </a>
                      <a href="exercise">
                          <li>Exercise</li>
                      </a>
                      <a href="shop">
                          <li>Shop</li>
                      </a>
                      <a href="blog-right-sidebar.html">
                          <li>Blog</li>
                      </a>
                      <a href="contact.html">
                          <li>Contact</li>
                      </a>
                  </ul>
              </div>

          </div>
      </div>

  </footer>
<?php /**PATH C:\xampp\htdocs\blog\resources\views/layouts/master.blade.php ENDPATH**/ ?>