<!-- Carousel Header -->
<header>
    <div id="carousel-header" class="carousel slide">
        <!-- Indicators -->
        <ol class="carousel-indicators hidden-xs">
            <li data-target="#carousel-header" data-slide-to="0" class="active"></li>
            <li data-target="#carousel-header" data-slide-to="1"></li>
            <li data-target="#carousel-header" data-slide-to="2"></li>
        </ol>
        <!-- Wrapper for slides -->
        <div class="carousel-inner">
            <div class="item active">
                <img class="img-responsive img-full" src="https://akcdn.detik.net.id/visual/2016/07/22/1e638d3a-7600-4c8c-be2b-21bd1c2ddba7_169.jpg?w=650" alt="">
                <div class="carousel-caption">
                    <h3>Category</h3>
                    <p>Learn english</p>
                </div>
            </div>
            <div class="item">
                <a href="shop"><img class="img-responsive img-full"  src="https://www.mercedes-benz.com/wp-content/uploads/sites/3/2014/11/classic_store_museumsshop_d385089_3400x1440.jpg" alt=""></a>
                <div class="carousel-caption">
                    <h3>Shop</h3>
                    <p>Belanja di Sini</p>
                </div>
            </div>
            <div class="item">
                <img href="kuis" class="img-responsive img-full" src="http://www.arwini.com/wp-content/uploads/2017/04/Tips-Belajar-Aktif-Sepanjang-Bulan-Ramadhan.jpg" alt="">
                <div class="carousel-caption">
                    <h3>Exercise</h3>
                    <p>Uji kemampuanmu dengan latihan</p>
                </div>
            </div>
        </div>
        <!-- Controls -->
        <a class="left carousel-control" href="#carousel-header" data-slide="prev">
            <span class="icon-prev"></span>
        </a>
        <a class="right carousel-control" href="#carousel-header" data-slide="next">
            <span class="icon-next"></span>
        </a>
    </div>

    <!-- best selling -->
    <section class="page-section">
        <div class="container ">
            <div class="row">
                <div class="col-md-8 col-md-push-4">
                    <div class="col-md-12">
                        <h2 class="title-section"><span >BEST SELLING</span><br/><span class="title-regular">ENGLISH FOR EVERYONE</span></h2>
                        <hr class="title-underline" />
                    </div>
                    <div class="row">
                        <div class="col-md-6 ">
                            <div class="col-xs-2 box-icon">
                                <div class="fa fa-pencil "></div>
                            </div>
                            <div class="col-xs-10">
                                <h3>Easy to Learn</h3>
                            </div>
                            <div class="col-md-10 col-xs-offset-2">
                                <p>
                                    Buku ini sangat mudah untuk dipelajari anak anak dan juga memiliki konten yang lumayan banyak,
                                </p>
                            </div>
                        </div>
                        <div class="col-md-6 ">

                            <div class="col-xs-2 box-icon">
                                <div class="fa fa-wordpress "></div>
                            </div>
                            <div class="col-xs-10">
                                <h3>Tons of Vocabulary</h3>
                            </div>
                            <div class="col-md-10 col-xs-offset-2">
                                <p>
                                    Memiliki berbagai vocabulary dari bermacam macam kategori benda di lingkungan sekitar
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6 ">

                            <div class="col-xs-2 box-icon">
                                <div class="fa fa-eye "></div>
                            </div>
                            <div class="col-xs-10">
                                <h3>Colorful Display</h3>
                            </div>
                            <div class="col-md-10 col-xs-offset-2">
                                <p>
                                    Buku ini memiliki tampilan yang berwarna warni sehingga sangat menarik bagi anak anak
                                </p>
                            </div>
                        </div>
                        <div class="col-md-6 ">

                            <div class="col-xs-2 box-icon">
                                <div class="fa fa-bullseye "></div>
                            </div>
                            <div class="col-xs-10">
                                <h3>Free Online Audio</h3>
                            </div>
                            <div class="col-md-10 col-xs-offset-2">
                                <p>
                                    Buku ini menyediakan course menggunakan audio gratis secara online
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 col-md-pull-8 ">
                    <img class="img-responsive" src="img/eng.jpg" alt="" />
                </div>
            </div>
        </div>
    </section>
    <script src="bootstrap/js/bootstrap.min.js"></script>


</header>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\blog\resources\views/home.blade.php ENDPATH**/ ?>