<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});
Route::get('/home', 'PageController@home' );
Route::get('/shop', 'PageController@shop' );
Route::get('/category', 'PageController@category' );
Route::get('/animal', 'PageController@animal' );
Route::get('/buah', 'PageController@buah' );
Route::get('/kuis', 'PageController@kuis' );
Route::get('/buah', 'PageController@buah' );

Route::group(['prefix' => 'laravel-crud-image-gallery'], function () {
    Route::get('/', 'Crud4Controller@index');
    Route::match(['get', 'post'], 'create', 'Crud4Controller@create');
    Route::match(['get', 'put'], 'update/{id}', 'Crud4Controller@update');
    Route::delete('delete/{id}', 'Crud4Controller@delete');
});

Route::get('/home_user', 'User@index');
Route::get('/login', 'User@login');
Route::post('/loginPost', 'User@loginPost');
Route::get('/register', 'User@register');
Route::post('/registerPost', 'User@registerPost');
Route::get('/logout', 'User@logout');


Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');
