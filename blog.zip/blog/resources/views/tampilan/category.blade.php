@extends('layouts.master')

    <section class="page-section" id="sliders">
        <div class="container">
            <div class="row margin-bottom-50">
                <div class="col-md-12 text-center">
                    <h1 class="title-section"><span class="title-regular"><strong>Choose Your Category</strong></span><br/>Pilih kateogori yang kamu mau</h1>
                    <hr class="title-underline-center">
                </div>
            </div>
            <div class="row margin-bottom-60">
                <div class="col-sm-4">
                    <h2>Animal</h2>
                    <hr class="title-underline margin-bottom-15">
                    <a href="animal"><img class="img-thumbnail img-responsive margin-bottom-15" src="img/animal.jpg" alt="" /></a>
                    <p><a href="animal" class="btn btn-md btn-primary">Lihat</a></p>
                </div>
                <div class="col-sm-4">
                    <h2>Flower</h2>
                    <hr class="title-underline margin-bottom-15">
                    <a href="index-header-product.html"><img class="img-thumbnail img-responsive margin-bottom-15" src="img/flower.jpg" alt="" /></a>
                    <p><a href="index-header-product.html" class="btn btn-md btn-primary">Lihat</a></p>
                </div>
                <div class="col-sm-4">
                    <h2>Fruits</h2>
                    <hr class="title-underline margin-bottom-15">
                    <a href="index-header-video.html"><img class="img-thumbnail img-responsive margin-bottom-15" src="img/buah/stroberi.jpg" alt="" /></a>
                    <p><a href="index-header-video.html" class="btn btn-md btn-primary">Lihat</a></p>
                </div>
            </div>
            <div class="row">
                <div class="col-sm-4">
                    <h2>Newsletter</h2>
                    <hr class="title-underline margin-bottom-15">
                    <a href="index-header-newsletter.html"><img class="img-thumbnail img-responsive margin-bottom-15" src="http://placehold.it/690x290" alt="" /></a>
                    <p><a href="index-header-newsletter.html" class="btn btn-md btn-primary">Open Newsletter Header</a></p>
                </div>
                <div class="col-sm-4">
                    <h2>Classic Carousel</h2>
                    <hr class="title-underline margin-bottom-15">
                    <a href="index-header-carousel.html"><img class="img-thumbnail img-responsive margin-bottom-15" src="http://placehold.it/690x290" alt="" /></a>
                    <p><a href="index-header-carousel.html" class="btn btn-md btn-primary">Open Carousel Header</a></p>
                </div>
                <div class="col-sm-4">
                    <h2>Classic Carousel</h2>
                    <hr class="title-underline margin-bottom-15">
                    <a href="index-header-carousel.html"><img class="img-thumbnail img-responsive margin-bottom-15" src="http://placehold.it/690x290" alt="" /></a>
                    <p><a href="index-header-carousel.html" class="btn btn-md btn-primary">Open Carousel Header</a></p>
                </div>
            </div>
        </div>
    </section>
  <script src="bootstrap/js/bootstrap.min.js"></script>
